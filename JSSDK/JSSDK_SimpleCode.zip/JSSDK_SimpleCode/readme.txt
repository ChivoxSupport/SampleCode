
1. Fill the appkey into the index_ Recorder.html��


2. Fill appkey and secretkey into PHP/sig.php;


3. Deploying the entire folder in the web server requires HTTPS protocol;


4. Visit index_ Recorder.html to experience the scoring function;


5. Refer to "kernel documentation" for detailed interface description;
